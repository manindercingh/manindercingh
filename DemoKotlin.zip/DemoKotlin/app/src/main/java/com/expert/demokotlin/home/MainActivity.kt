package com.expert.demokotlin.home

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.expert.demokotlin.R
import com.expert.demokotlin.adapters.AllNotesAdapter
import com.expert.demokotlin.add_notes.AddNoteActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setAdapter()
        setClicks()

    }

    private fun setAdapter() {

        val rvNotes = findViewById<RecyclerView>(R.id.rvNotes)
        val adapter = AllNotesAdapter()
        rvNotes.adapter = adapter

    }

    private fun setClicks() {

        imgAddNotes.setOnClickListener {
            val intent = Intent(this, AddNoteActivity::class.java)
            startActivity(intent)
        }

    }
}