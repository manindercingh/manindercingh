package com.expert.demokotlin.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "userNotes")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val notes: String,
    val date: String,
)