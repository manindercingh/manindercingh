package com.expert.demokotlin.add_notes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.expert.demokotlin.R
import com.expert.demokotlin.database.User
import com.expert.demokotlin.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.activity_add_note.*
import java.text.SimpleDateFormat
import java.util.*

class AddNoteActivity : AppCompatActivity() {
        private lateinit var mUserViewModel: UserViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_add_note)
        mUserViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        val sdf = SimpleDateFormat("dd-MMMM-yyyy")
        val currentDate = sdf.format(Date())
        txtDate.text = currentDate
        imgBack.setOnClickListener { onBackPressed() }
        imgDone.setOnClickListener { addNoteToDatabase() }

    }

    private fun addNoteToDatabase() {

        val sdf = SimpleDateFormat("dd-MMMM-yyyy").format(Date())
        val strNote = edtNotes.text.toString().trim()

        if (strNote.isNotEmpty()) {

//            val user : User
//            user.copy(1,strNote,sdf)

//    val user : User

            Toast.makeText(this, "Successfully Added", Toast.LENGTH_SHORT)
                .show()
            onBackPressed()

        } else {
            Toast.makeText(this, "Write a note first", Toast.LENGTH_SHORT)
                .show()
        }

    }
}